import cv2,os,urllib.request
import numpy as np
from django.conf import settings
import datetime
from django.shortcuts import render
from datetime import datetime
from glob import glob
import face_recognition as fr
from .models import AddCamera
from playsound import playsound

root_path= "static/Known/"

dict={}

def query_for_searcing_cam_values(user_name, name, password, ip_address, cam_no):
	rel_ip=f"rtsp://{name}:{password}@{ip_address}:554/{cam_no}"

	if user_name not in dict:
		dict[user_name] = []

	if user_name in dict:
		dict[user_name].append(rel_ip)




def get_all_cam_list():
	values=AddCamera.objects.all()
	for row in values:
		user_name=str(row.User_Name).replace("User: ",'')
		cam_name=row.Name
		password=row.Password
		ip_address= row.Ip_Adderss
		cam_on= row.Camera_Number
		query_for_searcing_cam_values(user_name, cam_name, password, ip_address, cam_on)

def help_for_get_index(use_name, ips):
	un=str(use_name)
	ip=str(ips)
	index_count = 0
	for key, vals in dict.items():
		for val in vals:
			index_count += 1
			if key == un and val==ip:
				return index_count-1
				#return index_count

def delete_videos():
	name_path = "../static/Stroge videos/*/"
	for name in glob(name_path):
		video_path = f"{name}*.*"
		print(video_path)
		for sl, videos in enumerate(glob(video_path)):
			if sl >= 1:
				os.remove(videos)


def help_for_get_key(index):
	len = 5
	index_count = 0
	for key, vals in dict.items():
		for val in vals:
			index_count += 1
			if index_count == len:
				return key

class VideoCamera(object):
	user_name=None
	ip_add=None
	video_createing_index=0
	cam_list=[]

	temp = " "

	path="static/Known/*.*"

	def __init__(self):
		#print('from camera ', self.user_name)
		get_all_cam_list()

		self.know_face_encoding = []
		for vals in dict.values():
			for val in vals:
				self.cam_list.append(val)

		#cam_list=  ["rtsp://admin:hik12345@103.80.71.74:554/1", 0]

		self.video = [cv2.VideoCapture(i) for i in self.cam_list]
		self.img = cv2.resize(cv2.imread('/home/saiful/PycharmProjects/smart secutrty system web application/camapp/there-is-no-connected-camera-mac.jpg'), (888, 500))

		self.frames = [None] * len(self.cam_list)
		self.ret = [None] * len(self.cam_list)
		self.resize = [None] * len(self.cam_list)


		for image in glob(self.path):
			try:
				img = fr.load_image_file(image)
				face = fr.face_encodings(img)[0]
				self.know_face_encoding.append(face)
			except:
				pass

	def __del__(self):
		#self.out.release()
		for video in self.video:
			video.release()

		for vm in self.video_make:
			vm.release()
		#self.out.release()

	def get_frame(self):

		index=help_for_get_index(self.user_name, self.ip_add)

		cdt = datetime.now()
		hours = cdt.strftime("%M")

		if self.temp !=hours:
			for key, valus in dict.items():
				for val in valus:
					self.video_make=[cv2.VideoWriter(f'../static/Stroge videos/{key}/{hours}.avi', cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'), 30, (1280, 720))]
			delete_videos()


		for i, c in enumerate(self.video):
			if c is not None:
				self.ret[i], self.frames[i] = c.read()

		for i, f in enumerate(self.frames):
			if self.ret[i] is True:
				face_locations_entry = fr.face_locations(f)
				face_encodings_entry = fr.face_encodings(f, face_locations_entry)
				for face_encoding_entry, (top, right, bottom, left) in zip(face_encodings_entry, face_locations_entry):
					cv2.rectangle(f, (left, top), (right, bottom), (0, 255, 0), 5)
					matching = fr.compare_faces(self.know_face_encoding, face_encoding_entry)
					face_destance = fr.face_distance(self.know_face_encoding, face_encoding_entry)
					index = np.argmin(face_destance)
					if matching[index]:
						cv2.putText(f, "Known", (left, top), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255), 1)
					else:
						cv2.putText(f, "Unknown", (left, top), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 1)
						key_value=str(help_for_get_key(i))
						cv2.putText(f, key_value, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 1)
						#playsound("static/Iphone Alarm.mp3")

				self.resize[i] = f
				#self.video_make[i].write(f)

		ret, jpeg = cv2.imencode('.jpg', self.resize[index])

		return jpeg.tobytes()


class IPWebCam(object):
	def __init__(self):
		self.video = cv2.VideoCapture('static/Funny CCTV VIDEOS _ funny videos _ Comedy videos _ Comedy funny videos.mp4')

	def __del__(self):
		cv2.destroyAllWindows()

	def get_frame(self):
		success, image = self.video.read()
		# We are using Motion JPEG, but OpenCV defaults to capture raw images,
		# so we must encode it into JPEG in order to correctly display the
		# video stream.
		frame_flip = cv2.flip(image,1)

		ret, jpeg = cv2.imencode('.jpg', frame_flip)
		return jpeg.tobytes()

		
class LiveWebCam(object):
	def __init__(self):
		self.url = cv2.VideoCapture("rtsp://admin:Mumbai@123@203.192.228.175:554/")

	def __del__(self):
		cv2.destroyAllWindows()

	def get_frame(self):
		success,imgNp = self.url.read()
		resize = cv2.resize(imgNp, (640, 480), interpolation = cv2.INTER_LINEAR) 
		ret, jpeg = cv2.imencode('.jpg', resize)
		return jpeg.tobytes()
