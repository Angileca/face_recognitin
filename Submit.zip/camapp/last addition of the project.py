user_list=[[564,1,41], [546,57465,4165,7845,4125,45],[65,46541,32,41]]

all_cam_list=[]

for row in user_list:
    for col in row:
        all_cam_list.append(col)


cam_name=57465
index=all_cam_list.index(cam_name)

print()

