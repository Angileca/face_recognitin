from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class AddCamera(models.Model):
    Name=models.CharField(max_length=50)
    User_Name=models.ForeignKey(User,on_delete=models.CASCADE)
    Password=models.CharField(max_length=50)
    Ip_Adderss=models.CharField(max_length=50)
    Camera_Number=models.CharField(max_length=50)
    def __str__(self):
        return str(self.User_Name)