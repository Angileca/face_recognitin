know_face_encoding = []
image_path = root_path + self.user_name + '*.*'
for image in glob(image_path):
    try:
        img = fr.load_image_file(image)
        face = fr.face_encodings(img)[0]
        know_face_encoding.append(face)
        whole_name = image.split('/')[-1]
        name = whole_name.split('.')[0]
    # know_face_name.append(name)
    except:
        pass


face_locations_entry = fr.face_locations(frame)

face_encodings_entry = fr.face_encodings(frame, face_locations_entry)
for face_encoding_entry, (top, right, bottom, left) in zip(face_encodings_entry, face_locations_entry):
    matching = fr.compare_faces(self.know_face_encoding, face_encoding_entry)
    face_destance = fr.face_distance(self.know_face_encoding, face_encoding_entry)
    index = np.argmin(face_destance)
    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 5)
    if matching[index]:
        cv2.putText(frame, "Known", (left, top), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255), 1)
    else:
        cv2.putText(frame, "Unknown", (left, top), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255), 1)
