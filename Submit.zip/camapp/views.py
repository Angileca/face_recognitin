import json
import os
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth, messages
#model
from .models import AddCamera
#Cam CODE
from .camera import VideoCamera, IPWebCam, LiveWebCam
from django.http.response import StreamingHttpResponse, HttpResponse
# Create your views here.

from .camera import VideoCamera


know_person_path="static/Known/"#This is the path for read known persons face fecer

storoge_video_path="static/Stroge videos/" #Stroge 48 hours video save in the folders

#login for admin
def index(request):
    if request.user.is_superuser:
        user=User.objects.all()
        cams=AddCamera.objects.all()
        print(cams)
        sendvar={
          "user":user,
           "cams":cams
        }
        return render(request,"newadmin.html",sendvar)

    elif request.user.is_authenticated:
        mycam=AddCamera.objects.filter(User_Name=request.user).order_by("-id")
        context={
            'mycams':mycam,
        }
        return render(request,"index.html",context)
    return redirect(login)

# login for local users
def login(request):
    email=request.POST.get("email")
    passw=request.POST.get("password")
    if request.method=="POST":
       user=auth.authenticate(username=email,password=passw)
       if user is not None:
            auth.login(request,user)
            #VideoCamera.user_name=user
            return redirect(index) 
       else:
            return render(request,"login.html",{'error':"Invalide User Password"})
    return render(request,"login.html")

def singup(request):
    if request.user.is_superuser:
        f_name=request.POST.get("f_name")
        l_name=request.POST.get("l_name")
        email=request.POST.get("email")
        passw=request.POST.get("password")
        cpassw=request.POST.get("confirmpassword")
        if request.method=="POST":
            if passw==passw:
                try:
                    user=User.objects.get(username=email)
                    return render(request,"singup.html",{'error':"User already exists"})  
                except User.DoesNotExist:
                    user=User.objects.create_user(username=email,password=cpassw,first_name=f_name,last_name=l_name)

                    path_name_for_known_faces=know_person_path+str(user)
                    os.mkdir(path_name_for_known_faces)#make now folder for storage known person's face

                    path_name_for_video_storage=storoge_video_path+str(user)
                    os.mkdir(path_name_for_video_storage)#make now folder for storage videos

                    return render(request,"singup.html",{'success':"user created successfully"})    
        else:
            return render(request,"singup.html") 
    else:
        return redirect(index)

def client_details(request):
    if request.user.is_superuser:
        return render(request,"client_details.html")
    return redirect(index)

def admin_page(request):
    if request.user.is_superuser:
        user=User.objects.all()
        sendvar={
          "user":user
        }
        return render(request,"admin_page.html",sendvar)
    return redirect(index)
    

def client_view(request,id):
    if request.user.is_superuser:
        user=User.objects.filter(id=id)
        sendvar={
          "user":user  
        }
        return render(request,"client_view.html",sendvar)
    return redirect(index)

def delete(request,id):
    if request.method=="POST":
        pk=User.objects.get(pk=id)
        pk.delete()
        return redirect(admin_page)

def logout(request):
    auth.logout(request)
    return redirect(index)


#CAM Code.........
def gen(camera):
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')


def video_feed(request):
    return StreamingHttpResponse(gen(VideoCamera()),
                    content_type='multipart/x-mixed-replace; boundary=frame')


def webcam_feed(request):
    return StreamingHttpResponse(gen(IPWebCam()),
                    content_type='multipart/x-mixed-replace; boundary=frame')


def livecam_feed(request):
    return StreamingHttpResponse(gen(LiveWebCam()),
                    content_type='multipart/x-mixed-replace; boundary=frame')


def CheckIP(request):
    body = json.loads(request.body)
    id = body['ipaddress_id']
    ip=AddCamera.objects.get(id=id)
    #VideoCamera.user_name=ip.User_Name
    user_name=ip.User_Name
    name=ip.Name
    password=ip.Password
    ip_address=ip.Ip_Adderss
    cam_no=ip.Camera_Number
    rel_add=f"rtsp://{name}:{password}@{ip_address}:554/{cam_no}"

    VideoCamera.user_name=user_name
    VideoCamera.ip_add=rel_add

    return HttpResponse("done")


def Adduser(request):
    if request.method=='POST':
        username=request.POST['username']
        password1=request.POST['pass1']
        password2=request.POST['pass2']

        if User.objects.filter(username=username).exists():
            messages.error(request,'Username already exist',extra_tags='signup')
            return redirect(request.POST['next'])
        elif password1==password2:
            user=User.objects.create_user(
                username=username,password=password1
            )
            user.save()
            messages.error(request, 'New user create succesfully', extra_tags='signup')
            os.mkdir(f"static/Stroge videos/{username}")
            return redirect(request.POST['next'])
        else:
            messages.error(request, 'Password not matching', extra_tags='signup')
            return redirect(request.POST['next'])


def AdduserCamera(request):
    if request.method=="POST":
        cname=request.POST.get('camname')
        cpass=request.POST.get('password')
        cip=request.POST.get('ipaddress')
        cno=request.POST.get('cno')

        cam=AddCamera.objects.create(
            User_Name=request.user,Name=cname,Password=cpass,Ip_Adderss=cip,Camera_Number=cno
        )
        cam.save()
        messages.success(request,'camera added successfully',extra_tags='addcam')
        return redirect(request.POST['next'])
    return render(request,'addcamera.html')


def Deletecams(request,id):
    if AddCamera.objects.filter(id=id).exists():
        cam=AddCamera.objects.get(id=id)
        if request.user==cam.User_Name:
            cam.delete()
            return redirect('home')
        else:
            return HttpResponse("<h1>You are not allow to delete other camera</h1>")